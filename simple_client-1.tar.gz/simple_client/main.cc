// Under the GPL with OpenSSL exception, see the libtorrent license.
//
// This program is pretty minimal, but shows most of the steps
// required to download a torrent.

#include <cerrno>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <torrent/torrent.h>
#include <torrent/http.h>
#include <torrent/poll_select.h>
#include <sigc++/bind.h>
#include <sigc++/hide.h>

#include "curl_get.h"
#include "curl_stack.h"

bool doShutdown = false;

void
chunk_passed(torrent::Download d) {
  std::cout << d.name() << ' ' << d.chunks_done() << '/' << d.chunks_total() << std::endl;
}

void
finished_download(torrent::Download d) {
  std::cout << "Finished: " << d.name() << std::endl;

  d.stop();

  // torrent::Download::close() closes the tracker manager, so it
  // won't send the STOPPED message. Do this later.
  //d.close();

  torrent::listen_close();

  // Do a quick shutdown without cleaning up or sending messages to
  // the trackers.
  doShutdown = true;
}

void
hash_check_done(torrent::Download d) {
  std::cout << "Hash check completed." << std::endl;
  d.start();
  chunk_passed(d);
}

void
http_done(torrent::Http* curlGet) {
  curlGet->close();
  std::cout << "Finished http download." << std::endl << std::flush;

  torrent::Download d = torrent::download_add(curlGet->stream());

  d.signal_hash_done(sigc::bind(sigc::ptr_fun(&hash_check_done), d));
  d.signal_download_done(sigc::bind(sigc::ptr_fun(&finished_download), d));
  d.signal_chunk_passed(sigc::hide(sigc::bind(sigc::ptr_fun(&chunk_passed), d)));
  d.open();
  d.hash_check();
}

void
http_failed(const std::string& msg, torrent::Http* curlGet) {
  std::cout << "Failed http download: " << msg << "." << std::endl << std::flush;
}

int
main(int argc, char** argv) {
  try {
    if (argc != 2)
      throw std::runtime_error("Wrong number of arguments.");
    
    // Network connections can throw SIGPIPE, so it is best to ignore it.
    signal(SIGPIPE, SIG_IGN);

    // 512 max open sockets, just a random number. A real client
    // checks sysconf(OC_OPEN_MAX). libTorrent uses this to allocate a
    // resonable amount of file descriptors for open files, network
    // connections and some for the client to use.
    //
    // See torrent::initialize for the ratios.
    torrent::PollSelect* pollSelect = torrent::PollSelect::create(512);

    core::CurlStack::global_init();
    core::CurlStack curlStack;

    // 'torrent::Http::set_factory(...)' must be set to a slot that
    // will create an object that handle http downloads. This is used
    // for tracker requests.
    torrent::Http::set_factory(curlStack.get_http_factory());
    torrent::Http* curlGet = torrent::Http::call_factory();

    torrent::initialize(pollSelect);

    // Fix the bug caused by not calling this?
    if (!torrent::listen_open(10000, 14000))
      throw std::runtime_error("Could not open a listening port.");

    std::stringstream httpDownload;

    curlGet->signal_done().connect(sigc::bind(sigc::ptr_fun(&http_done), curlGet));
    curlGet->signal_failed().connect(sigc::bind(sigc::ptr_fun(&http_failed), curlGet));
    curlGet->set_url(argv[1]);
    curlGet->set_stream(&httpDownload);
    curlGet->start();

    std::cout << "Starting download." << std::endl;

    fd_set readSet;
    fd_set writeSet;
    fd_set errorSet;

    // Shutdown should wait for torrent::is_inactive to return true,
    // with a resonable timeout. This will make sure trackers receive
    // the STOPPED message.

    while (!doShutdown) {
      FD_ZERO(&readSet);
      FD_ZERO(&writeSet);
      FD_ZERO(&errorSet);

      unsigned int maxFd = pollSelect->fdset(&readSet, &writeSet, &errorSet);

      if (curlStack.is_busy())
	maxFd = std::max(maxFd, curlStack.fdset(&readSet, &writeSet, &errorSet));

      int64_t t = std::min<int64_t>(1000000, torrent::next_timeout());
      timeval timeout = { t / 1000000, t % 1000000 };

      if (select(maxFd + 1, &readSet, &writeSet, &errorSet, &timeout) == -1 &&
	  errno != EINTR)
	throw std::runtime_error("Error polling.");

      if (curlStack.is_busy())
	curlStack.perform();

      // 'torrent::perform()' updates the cached time and runs any
      // scheduled tasks. We call it again to remove any task that
      // might have immediate timeout or that have timed out during
      // the call to 'pollSelect::perform(...)'.
      torrent::perform();
      pollSelect->perform(&readSet, &writeSet, &errorSet);
      torrent::perform();
    }

    // Cleanup is for the weak.
    torrent::cleanup();

    core::CurlStack::global_cleanup();
    delete pollSelect;

  } catch (std::exception& e) {
    std::cout << "Caught: " << e.what() << std::endl;
  }
  
  return 0;
}
